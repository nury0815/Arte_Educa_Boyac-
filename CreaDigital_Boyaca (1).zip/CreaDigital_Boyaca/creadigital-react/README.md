# CreaDigital Boyacá - React + Firebase

Versión moderna con autenticación y Firestore (esqueleto). Reemplace las variables de Firebase en .env.local antes de ejecutar.

## Instrucciones rápidas
1. Clonar repo
2. npm install
3. Crear .env.local con las variables REACT_APP_FIREBASE_...
4. npm start

## Notas
- No subir credenciales al repositorio.
- Scripts para poblar Firestore en scripts/seedFirestore.js
