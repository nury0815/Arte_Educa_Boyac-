// Script de ejemplo para poblar Firestore con datos demo (Node.js)
// NOTA: configurar GOOGLE_APPLICATION_CREDENTIALS o usar el SDK admin con cuidado
/*
const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');
admin.initializeApp({credential: admin.credential.cert(serviceAccount)});
const db = admin.firestore();
const artworks = [
  {title:'Paisaje rural',author:'Ana',imageUrl:'https://...'},
  {title:'Música y color',author:'Juan',imageUrl:'https://...'}
];
async function seed(){
  for(const a of artworks){
    await db.collection('artworks').add(a);
    console.log('Added', a.title);
  }
}
seed();
*/
console.log('Reemplace con credenciales y descomente para usar.');
