import React, {useEffect, useState} from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebaseConfig";

export default function Gallery(){
  const [items,setItems]=useState([]);
  useEffect(()=>{
    async function load(){
      try{
        const qSnap = await getDocs(collection(db,'artworks'));
        const data = qSnap.docs.map(d=>({id:d.id,...d.data()}));
        setItems(data);
      }catch(e){
        // si Firestore no está configurado, mostramos datos demo
        setItems([
          {id:1,title:'Paisaje rural',author:'Ana',imageUrl:'/assets/demo1.png'},
          {id:2,title:'Música y color',author:'Juan',imageUrl:'/assets/demo2.png'}
        ]);
      }
    }
    load();
  },[]);
  return (
    <div>
      <h2>Galería</h2>
      <div className="gallery">
        {items.map(it=>(
          <div key={it.id} className="card">
            <img src={it.imageUrl} alt={it.title} />
            <h4>{it.title}</h4>
            <p>{it.author}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
