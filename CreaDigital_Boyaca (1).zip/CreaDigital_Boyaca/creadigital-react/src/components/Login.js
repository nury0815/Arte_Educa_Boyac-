import React, {useState} from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebaseConfig";
import { useNavigate } from "react-router-dom";

export default function Login(){
  const [email,setEmail]=useState('');
  const [pw,setPw]=useState('');
  const navigate = useNavigate();
  const handle = async e=>{
    e.preventDefault();
    try{
      await signInWithEmailAndPassword(auth,email,pw);
      navigate('/admin');
    }catch(err){
      alert('Error: '+err.message);
    }
  };
  return (
    <div className="card">
      <h3>Iniciar sesión</h3>
      <form onSubmit={handle}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Correo" />
        <input type="password" value={pw} onChange={e=>setPw(e.target.value)} placeholder="Contraseña" />
        <button>Ingresar</button>
      </form>
    </div>
  );
}
