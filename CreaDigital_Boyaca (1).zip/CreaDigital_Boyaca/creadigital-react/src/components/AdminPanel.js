import React from "react";
export default function AdminPanel(){
  return (
    <div>
      <h2>Panel Administrativo</h2>
      <p>Gestión de usuarios, cursos y reportes.</p>
    </div>
  );
}
