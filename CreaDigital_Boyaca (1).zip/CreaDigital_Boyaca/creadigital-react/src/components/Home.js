import React from "react";

export default function Home(){
  return (
    <div>
      <h2>Bienvenido a CreaDigital Boyacá</h2>
      <p>Plataforma para educación y arte.</p>
    </div>
  );
}
