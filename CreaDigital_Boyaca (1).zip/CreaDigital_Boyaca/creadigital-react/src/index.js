import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import App from "./App";
import Home from "./components/Home";
import Gallery from "./components/Gallery";
import Login from "./components/Login";
import AdminPanel from "./components/AdminPanel";
import "./styles/app.css";

createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />}>
        <Route index element={<Home />} />
        <Route path="gallery" element={<Gallery />} />
        <Route path="login" element={<Login />} />
        <Route path="admin" element={<AdminPanel />} />
      </Route>
    </Routes>
  </BrowserRouter>
);
