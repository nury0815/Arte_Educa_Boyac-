// Reemplaza con tus datos; usa .env.local para seguridad
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_APIKEY || "REPLACE_API_KEY",
  authDomain: process.env.REACT_APP_FIREBASE_AUTHDOMAIN || "REPLACE",
  projectId: process.env.REACT_APP_FIREBASE_PROJECTID || "REPLACE",
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE || "REPLACE",
  messagingSenderId: process.env.REACT_APP_FIREBASE_MSGSENDER || "REPLACE",
  appId: process.env.REACT_APP_FIREBASE_APPID || "REPLACE"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
