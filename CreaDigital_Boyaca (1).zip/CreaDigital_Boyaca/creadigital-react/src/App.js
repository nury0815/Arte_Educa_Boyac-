import React from "react";
import { Outlet, Link } from "react-router-dom";

function App(){
  return (
    <div>
      <header className="header">
        <h1>CreaDigital Boyacá</h1>
        <nav>
          <Link to="/">Inicio</Link> | <Link to="/gallery">Galería</Link> | <Link to="/login">Ingresar</Link>
        </nav>
      </header>
      <main className="container"><Outlet/></main>
      <footer>© CreaDigital Boyacá</footer>
    </div>
  );
}
export default App;
