document.getElementById('year').textContent = new Date().getFullYear();

const modal = document.getElementById('modal');
const open = document.getElementById('openRegister');
const close = document.getElementById('closeModal');
open.addEventListener('click',()=> modal.classList.remove('hidden'));
close.addEventListener('click',()=> modal.classList.add('hidden'));

document.getElementById('registerForm').addEventListener('submit', e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  document.getElementById('regMessage').textContent = `Gracias ${data.name}, registro simulado exitoso.`;
  e.target.reset();
});
